![Struttura Generale Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Data Path venerdì 12 novembre 2021 15:04](c25d7fe01a0240f982d8bffcaa852f09.png)

    - I D-REGISTER sono simili fra loro, con lo stesso numero di bit. In essi si trovano le informazioni che vogliamo passare a ALU
    - Gli MPX decidono i due valori, fra quelli dei D-REGISTER, che andranno in ALU. Per via di ciò, i D-REGISTER dovranno essere di numero 2^n
    - L'U dell'ALU torna indietro e viene memorizzata in un apposito registro nel caso serva per immagazzinare valori temporanei
    - ES.
        - W = x + 7 - z
        - Calcolo prima t = x + 7, lo immagazzino
        - Calcolo W = t - z
    - CONTROL decide l'operazione da eseguire nell'ALU e se deve essere immagazzinato un eventuale valore temporaneo
    - Il suo valore viene deciso da un altro circuito, il CONTROL PATH

Creato con OneNote.
ALU
mercoledì 3 novembre 2021
15:23

    - Fino ad ora, le funzioni come AND, OR o NOT sono state implementate bit per bit.
    - Introduciamo ora un dispositivo, ALU (Unità Logica Aritmetica), la quale lavora su un numero di bit fissi, è controllata da C, ed è capace di numerose funzioni (AND, OR, XOR, +, -, /, *,…)

![Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna](17262d4042e340d09853aef9ebee2578.png)

    - Altre funzioni implementabili in essa sono, ad esempio, quella di ROTAZIONE

![Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna Disegni a penna](ba1d5660a9524242af73542f00457929.png)

    - Altri valori ottenibili sono:
        - CARRY: se si è ottenuto del resto
        - OVERFLOW: se il risultato ha un valore superiore alla quantità di bit predeterminata. Questo si nota particolarmente nel segno del numero, il quale sarà diverso da quello che ci si aspetti, dato che il "resto" finirà nel bit del segno
        - ZERO: se il risultato è uguale a 0. Basta unire con un NOR tutti i bit

Creato con OneNote.